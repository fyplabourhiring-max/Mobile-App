# 🌐 Smart Labor Hiring & Management System - Industry Side  
*Industry Side built with React JS*  

---  

## 📖 Overview  
This is the **Industry Side** for the **Smart Labor Hiring & Management System**, a location-based mobile application designed for the textile industry.  

The backend provides:  
- 🔐 Authentication & role-based accounts (Mills, Contractors, Workers)  
- 📄 REST APIs for job posting, contracts, reviews, and notifications  
- 🗄️ MongoDB database integration  
- 📍 Google Maps API integration for location-based matching  
- 🔔 Firebase push notifications support  

---  

## 🛠️ Tech Stack  

- 🌐 **React JS** – Runtime environment  
- ⚡ **Node.js** – Backend  
- 🍃 **MongoDB & Mongoose** – Database & ODM  
- 🔑 **JWT Authentication** – Secure login system  
- 🗺️ **Google Maps API** – Location-based search  
- 🔔 **Firebase** – Push notifications  

---   

## 📌 API Endpoints  

### Auth  
- `POST /api/auth/register` – Register new user (Worker / Contractor / Mill)  
- `POST /api/auth/login` – Login & receive JWT token  

### Jobs  
- `POST /api/jobs` – Post a new job (Contractor/Mill)  
- `GET /api/jobs` – Get available jobs (with location filters)  

### Contracts  
- `POST /api/contracts` – Create digital contract  
- `GET /api/contracts/:id` – Fetch contract details  

### Reviews  
- `POST /api/reviews` – Add review for worker/contractor  
- `GET /api/reviews/:id` – Fetch reviews  

---  

## 🌍 Vision  
This backend provides the **foundation** for a scalable labor management platform. Future updates will include:  
- 💳 Payment gateway integration  
- 📊 Analytics dashboard APIs  
- 🌐 Multi-language API support  

---  

## 📜 License  
This project is licensed under the **MIT License** – free to use, modify, and distribute.  

👉 **Developed with passion by [Zaibten](https://github.com/zaibten)**  
