import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import ViteLogo from '@/assets/vite.svg'

export default function SignIn() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const navigate = useNavigate()

  // Redirect if token exists
  // useEffect(() => {
  //   const token = localStorage.getItem('industryToken')
  //   if (token) {
  //     navigate('/', { replace: true }) // Prevent back navigation
  //   }
  // }, []) // ✅ no dependency on navigate to avoid multiple calls

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    try {
      const res = await fetch('https://labour-server.vercel.app/api/industries/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      })

      const data = await res.json()
      if (!res.ok) throw new Error(data.message || 'Login failed')

      // Save email and token in localStorage
      localStorage.setItem('industryEmail', data.email)
      localStorage.setItem('industryToken', data.token)

      // Redirect to homepage
      navigate('/', { replace: true }) // Prevent back navigation
    } catch (err: any) {
      alert(err.message)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className='container relative grid h-svh flex-col items-center justify-center lg:max-w-none lg:grid-cols-2 lg:px-0'>
      {/* Left Side */}
      <div className='relative hidden h-full flex-col bg-muted p-10 text-white dark:border-r lg:flex'>
        <div className='absolute inset-0 bg-zinc-900' />
        <div className='relative z-20 flex items-center text-lg font-medium'>
          <svg
            xmlns='http://www.w3.org/2000/svg'
            viewBox='0 0 24 24'
            fill='none'
            stroke='currentColor'
            strokeWidth='2'
            strokeLinecap='round'
            strokeLinejoin='round'
            className='mr-2 h-6 w-6'
          >
            <path d='M15 6v12a3 3 0 1 0 3-3H6a3 3 0 1 0 3 3V6a3 3 0 1 0-3 3h12a3 3 0 1 0-3-3' />
          </svg>
          Shadcn Admin
        </div>

        <img src={ViteLogo} className='relative m-auto' width={301} height={60} alt='Vite' />

        <div className='relative z-20 mt-auto'>
          <blockquote className='space-y-2'>
            <p className='text-lg'>
              &ldquo;This library has saved me countless hours of work and
              helped me deliver stunning designs to my clients faster than
              ever before.&rdquo;
            </p>
            <footer className='text-sm'>Sofia Davis</footer>
          </blockquote>
        </div>
      </div>

      {/* Right Side */}
      <div className='lg:p-8'>
        <div className='mx-auto flex w-full flex-col justify-center space-y-2 sm:w-[350px]'>
          <div className='flex flex-col space-y-2 text-left'>
            <h1 className='text-2xl font-semibold tracking-tight'>Login</h1>
            <p className='text-sm text-muted-foreground'>
              Enter your email and password below <br />
              to log into your account
            </p>
          </div>

          {/* Login Form */}
          <form className='space-y-4' onSubmit={handleLogin}>
            <input
              type='email'
              placeholder='Email'
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className='inputBox'
              required
            />
            <input
              type='password'
              placeholder='Password'
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className='inputBox'
              required
            />
            <button
              type='submit'
              disabled={loading}
              className='w-full mt-3 rounded-xl bg-primary py-3 text-white font-semibold shadow-lg hover:bg-primary/90 transition-all'
            >
              {loading ? 'Logging in...' : 'Login'}
            </button>
          </form>

          {/* Sign up redirect */}
          <p className='text-center text-sm text-muted-foreground mt-4'>
            Don't have an account?{' '}
            <span
              className='underline text-primary cursor-pointer hover:text-primary/80'
              onClick={() => navigate('/sign-up')}
            >
              Sign Up
            </span>
          </p>

          <p className='px-8 text-center text-sm text-muted-foreground mt-2'>
            By clicking login, you agree to our{' '}
            <a
              href='/terms'
              className='underline underline-offset-4 hover:text-primary'
            >
              Terms of Service
            </a>{' '}
            and{' '}
            <a
              href='/privacy'
              className='underline underline-offset-4 hover:text-primary'
            >
              Privacy Policy
            </a>
            .
          </p>
        </div>
      </div>

      <style>{`
        .inputBox {
          width: 100%;
          border-radius: 12px;
          border: 1px solid #d1d5db;
          padding: 14px 18px;
          font-size: 15.5px;
          background: #ffffff;
          transition: 0.25s ease;
          box-shadow: 0 1px 4px rgba(0,0,0,0.08);
        }
        .inputBox:hover { box-shadow: 0 2px 8px rgba(0,0,0,0.12); }
        .inputBox:focus {
          outline: none;
          border-color: var(--primary);
          box-shadow: 0 0 0 2px rgba(0,120,255,0.25);
          transform: scale(1.01);
        }
      `}</style>
    </div>
  )
}
