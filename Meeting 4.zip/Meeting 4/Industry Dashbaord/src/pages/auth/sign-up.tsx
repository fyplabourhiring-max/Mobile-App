import { Card } from '@/components/ui/card'
import { Link } from 'react-router-dom'
import { useState, useCallback } from 'react'
import { GoogleMap, Marker, useJsApiLoader } from '@react-google-maps/api'
import { useNavigate } from 'react-router-dom'


export default function SignUp() {
  const [phoneType, setPhoneType] = useState<'sim' | 'landline'>('sim')
  const [phone, setPhone] = useState('')
  const [showPassword, setShowPassword] = useState(false)
  const [address, setAddress] = useState('')
  const [textileType, setTextileType] = useState('')
  const [mapCenter, setMapCenter] = useState({ lat: 24.8607, lng: 67.0011 }) // Default Karachi
  const [showModal, setShowModal] = useState(false) // Modal state
  const navigate = useNavigate() // Router navigation

  
    // Redirect if token exists
    // useEffect(() => {
    //   const token = localStorage.getItem('industryToken')
    //   if (token) {
    //     navigate('/', { replace: true }) // Prevent back navigation
    //   }
    // }, [navigate])
  

  const { isLoaded } = useJsApiLoader({
    googleMapsApiKey: 'AIzaSyCdLAHV2BMZg_vfQcb8PZc9WggHr0w_U0A', // Replace with your key
  })

const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    const form = e.currentTarget
    const industry = (form.elements.namedItem('industry') as HTMLInputElement).value
    const owner = (form.elements.namedItem('owner') as HTMLInputElement).value
    const email = (form.elements.namedItem('email') as HTMLInputElement).value
    const phoneVal = (form.elements.namedItem('phone') as HTMLInputElement).value
    const addressVal = (form.elements.namedItem('address') as HTMLInputElement).value
    const textileTypeVal = (form.elements.namedItem('textileType') as HTMLSelectElement).value
    const passwordVal = (form.elements.namedItem('password') as HTMLInputElement).value

    if (!industry || !owner || !email || !phoneVal || !addressVal || !textileTypeVal || !passwordVal) {
      alert('All fields are required')
      return
    }

    try {
      const res = await fetch('https://labour-server.vercel.app/api/industries', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          industry,
          owner,
          email,
          phone: phoneVal,
          address: addressVal,
          textileType: textileTypeVal,
          password: passwordVal
        })
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.message || 'Error registering industry')

      // Show success modal
      setShowModal(true)

      form.reset()
      setPhone('')
      setShowPassword(false)
      setAddress('')
      setTextileType('')

      // Auto-close modal & redirect to login
      setTimeout(() => {
        setShowModal(false)
        navigate('/sign-in') // Redirect to login
      }, 2500) // 2.5 seconds delay
    } catch (err: any) {
      alert(err.message)
    }
  }

  const handlePhoneInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let val = e.target.value.replace(/\D/g, '')
    if (phoneType === 'sim') val = '+92' + val.replace(/^(\+92)?/, '')
    else val = '021' + val.replace(/^(021)?/, '')
    setPhone(val)
  }

  const updateMapLocation = useCallback(async () => {
    if (!address) return
    try {
      const response = await fetch(
        `https://maps.googleapis.com/maps/api/geocode/json?address=${encodeURIComponent(address + ' ' + textileType)}&key=AIzaSyCdLAHV2BMZg_vfQcb8PZc9WggHr0w_U0A`
      )
      const data = await response.json()
      if (data.results?.length) {
        const loc = data.results[0].geometry.location
        setMapCenter({ lat: loc.lat, lng: loc.lng })
      }
    } catch (err) {
      console.error('Error fetching location:', err)
    }
  }, [address, textileType])

  const handleAddressChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setAddress(e.target.value)
    updateMapLocation()
  }
  const handleTextileTypeChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setTextileType(e.target.value)
    updateMapLocation()
  }

  return (
    <div className='w-full h-screen overflow-y-auto bg-white flex flex-col items-center pt-10 pb-20 px-4 space-y-6'>
      {/* HEADER */}
      <div className="flex items-center justify-center animate-slideUp">
        <svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='currentColor'
          strokeWidth='2' strokeLinecap='round' strokeLinejoin='round' className='mr-2 h-9 w-9 text-primary'>
          <path d='M15 6v12a3 3 0 1 0 3-3H6a3 3 0 1 0 3 3V6a3 3 0 1 0-3 3h12a3 3 0 1 0-3-3' />
        </svg>
        <h1 className="text-3xl font-bold tracking-wide text-gray-800">Textile Industry Portal</h1>
      </div>

      {/* FORM CARD */}
      <Card className="p-8 sm:p-10 shadow-xl border bg-white rounded-2xl animate-fadeIn w-full max-w-[800px] space-y-6">
        <h2 className="text-2xl font-semibold text-gray-900">Create Industry Account</h2>
        <p className="text-sm text-gray-600 mt-1">Fill out the form below to register your textile industry.
          <br />Already registered? <Link to="/sign-in" className="underline text-primary font-medium hover:text-primary/80">Sign In</Link>
        </p>

        <form className="space-y-4" onSubmit={handleSubmit}>
          <input required type="text" name="industry" placeholder="Industry Name" className="inputBox" />
          <input required type="text" name="owner" placeholder="Owner / Contact Person" className="inputBox" />
          <input required type="email" name="email" placeholder="Email Address" className="inputBox" />
          <div className="flex space-x-2">
            <select value={phoneType} onChange={(e) => setPhoneType(e.target.value as 'sim' | 'landline')} className="inputBox w-1/3">
              <option value="sim">SIM (+92)</option>
              <option value="landline">Landline (021)</option>
            </select>
            <input required type="text" name="phone" value={phone} onChange={handlePhoneInputChange}
              placeholder={phoneType === 'sim' ? '+92XXXXXXXXXX' : '021XXXXXXX'} className="inputBox w-2/3" />
          </div>
          <input required type="text" name="address" placeholder="Factory Location / Address" className="inputBox" value={address} onChange={handleAddressChange} />
          <select required name="textileType" className="inputBox" value={textileType} onChange={handleTextileTypeChange}>
            <option value="" disabled>Select Type of Textile Work</option>
            <option value="weaving">Weaving</option>
            <option value="spinning">Spinning</option>
            <option value="dyeing">Dyeing</option>
            <option value="printing">Printing</option>
            <option value="finishing">Finishing</option>
            <option value="other">Other</option>
          </select>
          {isLoaded && (
            <div className="w-full h-64 rounded-lg border">
              <GoogleMap center={mapCenter} zoom={15} mapContainerStyle={{ width: '100%', height: '100%' }}>
                <Marker position={mapCenter} />
              </GoogleMap>
            </div>
          )}
          <div className="relative">
            <input required type={showPassword ? 'text' : 'password'} name="password"
              placeholder="Password (min 8 characters)" className="inputBox pr-12" minLength={8} />
            <button type="button"
              className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-800"
              onClick={() => setShowPassword(!showPassword)}>
              {showPassword ? '🙈' : '👁️'}
            </button>
          </div>
          <button type="submit" className="w-full mt-3 rounded-xl bg-primary py-3 text-white text-lg font-semibold shadow-lg hover:bg-primary/90 hover:shadow-2xl transition-all">
            Create Account
          </button>
        </form>
      </Card>

{/* Modal */}
{showModal && (
  <div className="fixed inset-0 flex items-center justify-center bg-black/50 z-50 animate-fadeIn">
    <div className="bg-white rounded-3xl p-8 w-96 shadow-2xl space-y-6 transform transition-all duration-500 scale-0 animate-scaleIn">
      {/* Animated check icon */}
      <div className="flex items-center justify-center">
        <div className="w-20 h-20 rounded-full bg-green-100 flex items-center justify-center animate-bounce">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
          </svg>
        </div>
      </div>

      <h2 className="text-2xl font-bold text-gray-900 text-center">Success!</h2>
      <p className="text-gray-600 text-center">Industry record has been inserted successfully.</p>
      <button
        className="w-full bg-primary py-3 text-white font-semibold rounded-xl hover:bg-primary/90 transition-all"
        onClick={() => setShowModal(false)}
      >
        Close
      </button>
    </div>
  </div>
)}

<style>{`
  @keyframes fadeIn {
    from {opacity: 0;}
    to {opacity: 1;}
  }
  @keyframes scaleIn {
    0% {transform: scale(0);}
    70% {transform: scale(1.1);}
    100% {transform: scale(1);}
  }
  @keyframes bounce {
    0%, 100% {transform: translateY(0);}
    50% {transform: translateY(-10px);}
  }

  .animate-fadeIn { animation: fadeIn 0.3s ease-out forwards; }
  .animate-scaleIn { animation: scaleIn 0.5s ease-out forwards; }
  .animate-bounce { animation: bounce 1s infinite; }
`}</style>


      <style>{`
        .inputBox {
          width: 100%;
          border-radius: 12px;
          border: 1px solid #d1d5db;
          padding: 14px 18px;
          font-size: 15.5px;
          background: #ffffff;
          transition: 0.25s ease;
          box-shadow: 0 1px 4px rgba(0,0,0,0.08);
        }
        .inputBox:hover { box-shadow: 0 2px 8px rgba(0,0,0,0.12); }
        .inputBox:focus {
          outline: none;
          border-color: var(--primary);
          box-shadow: 0 0 0 2px rgba(0,120,255,0.25);
          transform: scale(1.01);
        }
      `}</style>
    </div>
  )
}
