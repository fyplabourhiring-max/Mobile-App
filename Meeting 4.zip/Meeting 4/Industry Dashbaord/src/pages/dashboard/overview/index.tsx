import { Layout } from '@/components/custom/layout'
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import { Tabs, TabsContent } from '@/components/ui/tabs'
import ThemeSwitch from '@/components/theme-switch'
import { UserNav } from '@/components/user-nav'
import { useEffect, useState } from 'react'

interface IndustryProfile {
  industry: string
  owner: string
  email: string
  phone: string
  address: string
  textileType: string
  createdAt: string
  updatedAt: string
}

export default function DashboardPage() {
  const [profile, setProfile] = useState<IndustryProfile | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const email = localStorage.getItem('industryEmail')
    if (!email) {
      // Redirect to login if not logged in
      window.location.href = '/sign-in'
      return
    }

    const fetchProfile = async () => {
      try {
        const res = await fetch(
          `https://labour-server.vercel.app/api/industries/profile?email=${email}`
        )
        const data = await res.json()
        if (!res.ok) throw new Error(data.message || 'Failed to fetch profile')
        setProfile(data)
      } catch (err: any) {
        alert(err.message)
      } finally {
        setLoading(false)
      }
    }

    fetchProfile()
  }, [])

  if (loading) {
    return (
      <div className='flex items-center justify-center h-screen'>
        <p className='text-lg font-medium'>Loading...</p>
      </div>
    )
  }

  return (
    <Layout>
      <Layout.Header
        sticky
        className='flex flex-col items-center justify-center p-4 shadow-md bg-white dark:bg-gray-900'
      >
        <h1 className='text-2xl font-bold tracking-tight text-black dark:text-white'>
          Dashboard
        </h1>
        <div className='absolute right-4 top-4 flex items-center space-x-4'>
          <ThemeSwitch />
          <UserNav />
        </div>
      </Layout.Header>

      <Layout.Body className='p-4'>
        <Tabs orientation='vertical' defaultValue='overview' className='space-y-4'>
          <TabsContent value='overview' className='space-y-4'>
            {/* Profile Card */}
            {profile && (
              <Card className='mb-4'>
                <CardHeader>
                  <CardTitle className='text-lg font-semibold'>Industry Profile</CardTitle>
                </CardHeader>
                <CardContent className='space-y-2'>
                  <p><strong>Industry:</strong> {profile.industry}</p>
                  <p><strong>Owner:</strong> {profile.owner}</p>
                  <p><strong>Email:</strong> {profile.email}</p>
                  <p><strong>Phone:</strong> {profile.phone}</p>
                  <p><strong>Address:</strong> {profile.address}</p>
                  <p><strong>Textile Type:</strong> {profile.textileType}</p>
                  <p><strong>Created At:</strong> {new Date(profile.createdAt).toLocaleString()}</p>
                  <p><strong>Updated At:</strong> {new Date(profile.updatedAt).toLocaleString()}</p>
                </CardContent>
              </Card>
            )}

            {/* Example Stats Cards */}
            <div className='grid gap-4 sm:grid-cols-2 lg:grid-cols-4'>
              <Card>
                <CardHeader className='flex justify-between pb-2'>
                  <CardTitle className='text-sm font-medium'>Total Laborers</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className='text-2xl font-bold'>+2350</div>
                  <p className='text-xs text-muted-foreground'>+180.1% from last month</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className='flex justify-between pb-2'>
                  <CardTitle className='text-sm font-medium'>Total Contractors</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className='text-2xl font-bold'>+2350</div>
                  <p className='text-xs text-muted-foreground'>+180.1% from last month</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className='flex justify-between pb-2'>
                  <CardTitle className='text-sm font-medium'>Sales</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className='text-2xl font-bold'>+12,234</div>
                  <p className='text-xs text-muted-foreground'>+19% from last month</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className='flex justify-between pb-2'>
                  <CardTitle className='text-sm font-medium'>Active Now</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className='text-2xl font-bold'>+573</div>
                  <p className='text-xs text-muted-foreground'>+201 since last hour</p>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </Layout.Body>
    </Layout>
  )
}
