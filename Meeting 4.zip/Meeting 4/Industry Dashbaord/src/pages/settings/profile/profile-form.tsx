import { z } from 'zod'
import { Link } from 'react-router-dom'
import { useFieldArray, useForm } from 'react-hook-form'
import { useEffect, useState } from 'react'
import { Button } from '@/components/custom/button'
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form'
import { Input } from '@/components/ui/input'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Textarea } from '@/components/ui/textarea'
import { toast } from '@/components/ui/use-toast'
import { cn } from '@/lib/utils'
import { zodResolver } from '@hookform/resolvers/zod'

const profileFormSchema = z.object({
  username: z.string().min(2).max(30),
  email: z.string().email(),
  bio: z.string().max(160).min(4).optional(),
  urls: z
    .array(
      z.object({
        value: z.string().url({ message: 'Please enter a valid URL.' }),
      })
    )
    .optional(),
})

type ProfileFormValues = z.infer<typeof profileFormSchema>

export default function ProfileForm() {
  const [loading, setLoading] = useState(true)

  const form = useForm<ProfileFormValues>({
    resolver: zodResolver(profileFormSchema),
    defaultValues: {},
    mode: 'onChange',
  })

  const { fields, append, reset } = useFieldArray({
    name: 'urls',
    control: form.control,
  })

  // Fetch industry profile from API
  useEffect(() => {
    const email = localStorage.getItem('industryEmail')
    if (!email) {
      window.location.href = '/sign-in'
      return
    }

    const fetchProfile = async () => {
      try {
        const res = await fetch(
          `https://labour-server.vercel.app/api/industries/profile?email=${email}`
        )
        const data = await res.json()
        if (!res.ok) throw new Error(data.message || 'Failed to fetch profile')

        // Map API data to form fields
        reset({
          username: data.owner,
          email: data.email,
          bio: `Industry: ${data.industry}, Type: ${data.textileType}`,
          urls: [], // can be filled if API provides links
        })
      } catch (err: any) {
        toast({ title: 'Error', description: err.message })
      } finally {
        setLoading(false)
      }
    }

    fetchProfile()
  }, [reset])

  function onSubmit(data: ProfileFormValues) {
    toast({
      title: 'Profile updated',
      description: (
        <pre className='mt-2 w-[340px] rounded-md bg-slate-950 p-4'>
          <code className='text-white'>{JSON.stringify(data, null, 2)}</code>
        </pre>
      ),
    })

    // Optional: Send update to backend
    // fetch('/api/industries/update', { method: 'POST', body: JSON.stringify(data) })
  }

  if (loading) return <p className='text-center mt-10'>Loading profile...</p>

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className='space-y-8'>
        <FormField
          control={form.control}
          name='username'
          render={({ field }) => (
            <FormItem>
              <FormLabel>Username</FormLabel>
              <FormControl>
                <Input placeholder='Owner Name' {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name='email'
          render={({ field }) => (
            <FormItem>
              <FormLabel>Email</FormLabel>
              <Select onValueChange={field.onChange} defaultValue={field.value}>
                <FormControl>
                  <SelectTrigger>
                    <SelectValue placeholder='Select email' />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  <SelectItem value={field.value}>{field.value}</SelectItem>
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name='bio'
          render={({ field }) => (
            <FormItem>
              <FormLabel>Bio</FormLabel>
              <FormControl>
                <Textarea placeholder='Industry Bio' {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <div>
          {fields.map((field, index) => (
            <FormField
              control={form.control}
              key={field.id}
              name={`urls.${index}.value`}
              render={({ field }) => (
                <FormItem>
                  <FormLabel className={cn(index !== 0 && 'sr-only')}>URLs</FormLabel>
                  <FormControl>
                    <Input {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          ))}
          <Button type='button' variant='outline' size='sm' className='mt-2' onClick={() => append({ value: '' })}>
            Add URL
          </Button>
        </div>

        <Button type='submit'>Update profile</Button>
      </form>
    </Form>
  )
}
