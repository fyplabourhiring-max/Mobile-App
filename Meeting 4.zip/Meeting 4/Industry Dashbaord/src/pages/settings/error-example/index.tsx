export default function ErrorExample() {
  throw Error('an error occurs while loading this component')
  return <h1>Error Example</h1>
}
