import { Outlet } from 'react-router-dom'
import Sidebar from './sidebar'
import useIsCollapsed from '@/hooks/use-is-collapsed'
import SkipToMain from './skip-to-main'
import { useLocation } from "react-router-dom";

export default function AppShell() {
  const [isCollapsed, setIsCollapsed] = useIsCollapsed()
  const location = useLocation();

  // Check pages where sidebar shouldn't be shown
  const hideSidebarPages = ["/sign-up", "/sign-in"]
  const shouldHideSidebar = hideSidebarPages.includes(location.pathname)

  return (
    <div className='relative h-full overflow-hidden'>
      <SkipToMain />

      {/* SHOW SIDEBAR ONLY ON NON-SIGNUP/SIGNIN PAGES */}
      {!shouldHideSidebar && (
        <Sidebar isCollapsed={isCollapsed} setIsCollapsed={setIsCollapsed} />
      )}

      <main
        id='content'
        className={`overflow-x-hidden transition-[margin] md:overflow-y-hidden md:pt-0 h-full
          ${!shouldHideSidebar ? (isCollapsed ? 'md:ml-14 bg-white' : 'md:ml-64 bg-white') : 'md:ml-0 bg-transparent'}
        `}
      >
        <Outlet />
      </main>
    </div>
  )
}
